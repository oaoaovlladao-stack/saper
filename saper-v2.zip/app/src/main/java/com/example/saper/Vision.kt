package com.example.saper

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Границы клеток внутри выделенной области (в пикселях области). */
class Grid(val xs: DoubleArray, val ys: DoubleArray)

/** Чтение поля из пикселей: поиск сетки, закрытые/открытые клетки, цифры. */
object Vision {
    private const val N = 8

    // Центр клетки (там рисуются метки) при определении «закрыта/открыта» не смотрим.
    private val FRAME: IntArray = (0 until N * N).filter { i ->
        !((i / N) in 2..5 && (i % N) in 2..5)
    }.toIntArray()

    // Цвета цифр 1..8: классический сапёр и стиль Google.
    private val PALETTE: Array<Array<IntArray>> = arrayOf(
        arrayOf(intArrayOf(0, 0, 255), intArrayOf(25, 118, 210)),
        arrayOf(intArrayOf(0, 128, 0), intArrayOf(56, 142, 60)),
        arrayOf(intArrayOf(255, 0, 0), intArrayOf(211, 47, 47)),
        arrayOf(intArrayOf(0, 0, 128), intArrayOf(123, 31, 162)),
        arrayOf(intArrayOf(128, 0, 0), intArrayOf(255, 143, 0)),
        arrayOf(intArrayOf(0, 128, 128), intArrayOf(0, 151, 167)),
        arrayOf(intArrayOf(0, 0, 0), intArrayOf(66, 66, 66)),
        arrayOf(intArrayOf(128, 128, 128), intArrayOf(158, 158, 158))
    )

    // ---------------------------------------------------------- сетка
    fun uniformGrid(w: Int, h: Int, rows: Int, cols: Int): Grid {
        return Grid(
            DoubleArray(cols + 1) { it * w.toDouble() / cols },
            DoubleArray(rows + 1) { it * h.toDouble() / rows }
        )
    }

    private fun smooth(g: DoubleArray, k: Int): DoubleArray {
        val n = g.size
        val pre = DoubleArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + g[i]
        return DoubleArray(n) { i ->
            val a = max(0, i - k)
            val b = min(n, i + k + 1)
            (pre[b] - pre[a]) / (b - a)
        }
    }

    /** Ищет начало и шаг n клеток по профилю перепадов яркости raw. Возвращает [начало, шаг]. */
    private fun fitAxis(raw: DoubleArray, n: Int, len: Int): DoubleArray {
        val g = smooth(raw, 3)
        val p0 = len.toDouble() / n
        var best = -1.0
        var bo = 0.0
        var bp = p0
        var p = p0 * 0.55
        while (p <= p0 * 1.15) {
            var o = -0.6 * p
            val hi = len - n * p + 0.6 * p
            while (o <= hi) {
                var sc = 0.0
                for (k in 0..n) {
                    val x = Math.round(o + k * p).toInt()
                    if (x >= 0 && x < g.size) sc += g[x]
                }
                if (sc > best) {
                    best = sc
                    bo = o
                    bp = p
                }
                o += 0.5
            }
            p += 0.1
        }
        // уточнение начала: у толстой рамки клетки сглаженный пик смещён, сырой точнее
        var ro = bo
        var rs = -1.0
        var o2 = bo - 6
        while (o2 <= bo + 6) {
            var sc = 0.0
            for (k in 0..n) {
                val x = Math.round(o2 + k * bp).toInt()
                if (x >= 0 && x < raw.size) sc += raw[x]
            }
            if (sc > rs) {
                rs = sc
                ro = o2
            }
            o2 += 0.5
        }
        return doubleArrayOf(ro + 1.0, bp)
    }

    fun detectGrid(px: IntArray, w: Int, h: Int, rows: Int, cols: Int): Grid {
        val g = IntArray(w * h)
        for (i in 0 until w * h) {
            val p = px[i]
            g[i] = (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100
        }
        val gx = DoubleArray(max(w - 1, 1))
        val gy = DoubleArray(max(h - 1, 1))
        for (y in 0 until h) {
            val o = y * w
            for (x in 0 until w - 1) {
                gx[x] += abs(g[o + x + 1] - g[o + x]).toDouble()
            }
            if (y < h - 1) {
                val o2 = o + w
                for (x in 0 until w) {
                    gy[y] += abs(g[o2 + x] - g[o + x]).toDouble()
                }
            }
        }
        val fx = fitAxis(gx, cols, w)
        val fy = fitAxis(gy, rows, h)
        return Grid(
            DoubleArray(cols + 1) { fx[0] + it * fx[1] },
            DoubleArray(rows + 1) { fy[0] + it * fy[1] }
        )
    }

    // ---------------------------------------------------------- клетки
    private fun box(g: Grid, r: Int, c: Int, w: Int, h: Int): IntArray {
        val x0 = max(0, g.xs[c].roundToInt())
        val y0 = max(0, g.ys[r].roundToInt())
        val x1 = min(w, g.xs[c + 1].roundToInt())
        val y1 = min(h, g.ys[r + 1].roundToInt())
        return if (x1 - x0 < 8 || y1 - y0 < 8) {
            intArrayOf(0, 0, min(w, 16), min(h, 16))
        } else {
            intArrayOf(x0, y0, x1, y1)
        }
    }

    private fun thumb(px: IntArray, w: Int, bx: IntArray): FloatArray {
        val out = FloatArray(N * N * 3)
        val cw = bx[2] - bx[0]
        val ch = bx[3] - bx[1]
        for (i in 0 until N) {
            val ya = bx[1] + ch * i / N
            val yb = max(ya + 1, bx[1] + ch * (i + 1) / N)
            for (j in 0 until N) {
                val xa = bx[0] + cw * j / N
                val xb = max(xa + 1, bx[0] + cw * (j + 1) / N)
                var sr = 0L
                var sg = 0L
                var sb = 0L
                var cnt = 0
                for (y in ya until yb) {
                    for (x in xa until xb) {
                        val p = px[y * w + x]
                        sr += (p shr 16) and 255
                        sg += (p shr 8) and 255
                        sb += p and 255
                        cnt++
                    }
                }
                val o = (i * N + j) * 3
                out[o] = sr.toFloat() / cnt
                out[o + 1] = sg.toFloat() / cnt
                out[o + 2] = sb.toFloat() / cnt
            }
        }
        return out
    }

    /** На чистом поле все клетки закрыты: усредняем их вид. */
    fun makeTemplate(px: IntArray, w: Int, h: Int, g: Grid): FloatArray {
        val rows = g.ys.size - 1
        val cols = g.xs.size - 1
        val acc = FloatArray(N * N * 3)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val t = thumb(px, w, box(g, r, c, w, h))
                for (i in acc.indices) acc[i] += t[i]
            }
        }
        val n = (rows * cols).toFloat()
        for (i in acc.indices) acc[i] /= n
        return acc
    }

    private fun diff(t: FloatArray, tpl: FloatArray): Float {
        var s = 0f
        for (f in FRAME) {
            for (ch in 0..2) s += abs(t[f * 3 + ch] - tpl[f * 3 + ch])
        }
        return s / (FRAME.size * 3)
    }

    private fun sq(a: Int, b: Int): Int = (a - b) * (a - b)

    /** Цифры-кандидаты от самой вероятной к менее вероятной; 0 (пусто) всегда в конце. */
    private fun candidates(px: IntArray, w: Int, bx: IntArray): IntArray {
        val cw = bx[2] - bx[0]
        val ch = bx[3] - bx[1]
        val xa = bx[0] + (cw * 0.28).roundToInt()
        val xb = bx[0] + (cw * 0.72).roundToInt()
        val ya = bx[1] + (ch * 0.2).roundToInt()
        val yb = bx[1] + (ch * 0.8).roundToInt()
        val area = (xb - xa) * (yb - ya)

        val hist = IntArray(4096)
        for (y in bx[1] until bx[3]) {
            for (x in bx[0] until bx[2]) {
                val p = px[y * w + x]
                val key = (((p shr 20) and 15) shl 8) or (((p shr 12) and 15) shl 4) or ((p shr 4) and 15)
                hist[key]++
            }
        }
        var bk = 0
        for (i in 1 until 4096) if (hist[i] > hist[bk]) bk = i
        val br = ((bk shr 8) and 15) * 16 + 8
        val bg = ((bk shr 4) and 15) * 16 + 8
        val bb = (bk and 15) * 16 + 8

        val pure = IntArray(9)
        val soft = IntArray(9)
        for (y in ya until yb) {
            for (x in xa until xb) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (sq(r, br) + sq(g, bg) + sq(b, bb) < 3600) continue
                var d1 = Int.MAX_VALUE
                var n1 = 0
                var d2 = Int.MAX_VALUE
                var n2 = 0
                for (n in 1..8) {
                    for (col in PALETTE[n - 1]) {
                        val d = sq(r, col[0]) + sq(g, col[1]) + sq(b, col[2])
                        if (d < d1) {
                            d1 = d
                            n1 = n
                        }
                        if (n <= 6 && d < d2) {
                            d2 = d
                            n2 = n
                        }
                    }
                }
                if (d1 < 1225) pure[n1]++
                if (d2 < 5625) soft[n2]++
            }
        }

        val score = DoubleArray(9)
        for (n in 1..8) {
            val sc: Double = if (n >= 7) {
                // серый и чёрный легко путаются с рамками и тенями: нужно много пикселей
                if (pure[n] >= max(8.0, area * 0.06)) pure[n].toDouble() else 0.0
            } else {
                pure[n] + 0.3 * soft[n]
            }
            if (sc >= max(3.0, area * 0.015)) score[n] = sc
        }
        val ranked = (1..8).filter { score[it] > 0.0 }.sortedByDescending { score[it] }
        val out = IntArray(ranked.size + 1)
        for (i in ranked.indices) out[i] = ranked[i]
        out[ranked.size] = 0
        return out
    }

    fun readBoard(px: IntArray, w: Int, h: Int, g: Grid, tpl: FloatArray): Array<IntArray> {
        val rows = g.ys.size - 1
        val cols = g.xs.size - 1
        val board = Array(rows) { IntArray(cols) { Solver.UNK } }
        val cand = HashMap<Int, IntArray>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val bx = box(g, r, c, w, h)
                if (diff(thumb(px, w, bx), tpl) >= 22f) {
                    val lst = candidates(px, w, bx)
                    cand[r * cols + c] = lst
                    board[r][c] = lst[0]
                }
            }
        }
        // проверка здравого смысла: цифра не может быть больше числа закрытых соседей
        for (pass in 0 until 3) {
            var fixed = false
            for ((key, lst) in cand) {
                val r = key / cols
                val c = key % cols
                val v = board[r][c]
                var cn = 0
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = r + dr
                        val nc = c + dc
                        if (nr in 0 until rows && nc in 0 until cols && board[nr][nc] == Solver.UNK) cn++
                    }
                }
                if (v > cn) {
                    board[r][c] = lst.firstOrNull { it <= cn } ?: 0
                    fixed = true
                }
            }
            if (!fixed) break
        }
        return board
    }
}
