package com.example.saper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var rowsEt: EditText
    private lateinit var colsEt: EditText
    private lateinit var minesEt: EditText

    private fun field(label: String, value: String, parent: LinearLayout): EditText {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val tv = TextView(this)
        tv.text = label
        tv.textSize = 18f
        tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val et = EditText(this)
        et.setText(value)
        et.inputType = InputType.TYPE_CLASS_NUMBER
        et.textSize = 18f
        et.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        row.addView(tv)
        row.addView(et)
        parent.addView(row)
        return et
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Помощник сапёра"
        title.textSize = 24f
        root.addView(title)

        val info = TextView(this)
        info.textSize = 15f
        info.text = "1. Нажмите «Запустить» и разрешите показ поверх других окон.\n" +
            "2. В окне записи экрана выберите «Весь экран» (не одно приложение).\n" +
            "3. Откройте игру (лучше новую партию, все клетки закрыты). Внизу экрана появится панель.\n" +
            "4. Нажмите «Поле» и коснитесь любой закрытой клетки — размер поля найдётся сам.\n" +
            "5. Открывайте клетки: зелёные — безопасно, красные — мины, жёлтая — лучший риск.\n" +
            "Флажки в игре не ставьте. Новая партия того же размера подхватится сама.\n\n" +
            "Автонажатия: кнопка ниже открывает «Специальные возможности» — включите там «Помощник сапёра: нажатия», " +
            "потом на панели нажмите «Авто».\n\n" +
            "Размер ниже нужен только для запасного режима «Вручн.»."
        root.addView(info)

        rowsEt = field("Строк", "16", root)
        colsEt = field("Столбцов", "30", root)
        minesEt = field("Мин", "99", root)

        val presets = LinearLayout(this)
        presets.orientation = LinearLayout.HORIZONTAL
        val sizes = arrayOf(intArrayOf(8, 8, 10), intArrayOf(9, 9, 10), intArrayOf(16, 16, 40), intArrayOf(16, 30, 99))
        for (sz in sizes) {
            val pb = Button(this)
            pb.text = sz[0].toString() + "×" + sz[1]
            pb.isAllCaps = false
            pb.setOnClickListener {
                rowsEt.setText(sz[0].toString())
                colsEt.setText(sz[1].toString())
                minesEt.setText(sz[2].toString())
            }
            presets.addView(pb)
        }
        root.addView(presets)

        val acc = Button(this)
        acc.text = "Включить автонажатия"
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        root.addView(acc)

        val start = Button(this)
        start.text = "Запустить"
        start.setOnClickListener { startHelper() }
        root.addView(start)

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Suppress("DEPRECATION")
    private fun startHelper() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разрешите «Поверх других окон» и вернитесь в приложение", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            i.putExtra("rows", rowsEt.text.toString().toIntOrNull() ?: 16)
            i.putExtra("cols", colsEt.text.toString().toIntOrNull() ?: 30)
            i.putExtra("mines", minesEt.text.toString().toIntOrNull() ?: 99)
            startForegroundService(i)
            finish()
        }
    }
}
