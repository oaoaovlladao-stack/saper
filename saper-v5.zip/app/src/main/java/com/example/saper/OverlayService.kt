package com.example.saper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Полупрозрачные метки поверх игры (клики проходят сквозь них). */
class MarksView(ctx: Context) : View(ctx) {
    private var rg: IntArray? = null
    private var grid: Grid? = null
    private var marks: Map<Int, IntArray> = emptyMap()
    private var cols = 1
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val frame = Paint()
    private var outline = false

    init {
        frame.style = Paint.Style.STROKE
        frame.strokeWidth = 8f
        frame.color = Color.rgb(0, 200, 83)
        txt.color = Color.BLACK
        txt.textAlign = Paint.Align.CENTER
        txt.isFakeBoldText = true
    }

    fun update(region: IntArray?, g: Grid?, m: Map<Int, IntArray>, c: Int) {
        rg = region
        grid = g
        marks = m
        cols = c
        invalidate()
    }

    fun setOutline(on: Boolean) {
        outline = on
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val r0 = rg ?: return
        if (outline) canvas.drawRect(r0[0].toFloat(), r0[1].toFloat(), r0[2].toFloat(), r0[3].toFloat(), frame)
        val g = grid ?: return
        for ((key, v) in marks) {
            val r = key / cols
            val c = key % cols
            if (r + 1 >= g.ys.size || c + 1 >= g.xs.size) continue
            val cw = g.xs[c + 1] - g.xs[c]
            val ch = g.ys[r + 1] - g.ys[r]
            val l = (r0[0] + g.xs[c] + cw * 0.25).toFloat()
            val t = (r0[1] + g.ys[r] + ch * 0.25).toFloat()
            val rr = (r0[0] + g.xs[c] + cw * 0.75).toFloat()
            val b = (r0[1] + g.ys[r] + ch * 0.75).toFloat()
            fill.color = when (v[0]) {
                0 -> Color.rgb(0, 200, 83)
                1 -> Color.rgb(255, 23, 68)
                else -> Color.rgb(255, 214, 0)
            }
            canvas.drawRect(l, t, rr, b, fill)
            if (v[0] == 2) {
                txt.textSize = (ch * 0.35).toFloat()
                canvas.drawText(v[1].toString(), (l + rr) / 2, (t + b) / 2 + txt.textSize / 3, txt)
            }
        }
    }
}

/** Затемнённый слой, на котором пальцем обводят поле. */
class SelectView(ctx: Context, private val onDone: (IntArray?) -> Unit) : View(ctx) {
    private var x0 = 0f
    private var y0 = 0f
    private var x1 = 0f
    private var y1 = 0f
    private var drag = false
    private val paint = Paint()

    init {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 6f
        paint.color = Color.GREEN
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x55000000)
        if (drag) {
            canvas.drawRect(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1), paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                x0 = e.rawX
                y0 = e.rawY
                x1 = x0
                y1 = y0
                drag = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                x1 = e.rawX
                y1 = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                x1 = e.rawX
                y1 = e.rawY
                drag = false
                if (Math.abs(x1 - x0) > 80 && Math.abs(y1 - y0) > 80) {
                    onDone(intArrayOf(minOf(x0, x1).toInt(), minOf(y0, y1).toInt(), maxOf(x0, x1).toInt(), maxOf(y0, y1).toInt()))
                } else {
                    onDone(null)
                }
            }
        }
        return true
    }
}

/** Затемнённый слой: «коснитесь любой закрытой клетки». */
class TapView(ctx: Context, private val onTap: (Int, Int) -> Unit) : View(ctx) {
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        tp.color = Color.WHITE
        tp.textSize = 46f
        tp.textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x66000000)
        canvas.drawText("Коснитесь любой ЗАКРЫТОЙ клетки", width / 2f, height * 0.12f, tp)
        canvas.drawText("(лучше на новой игре)", width / 2f, height * 0.12f + 60f, tp)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) onTap(e.rawX.toInt(), e.rawY.toInt())
        return true
    }
}

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var wh: Handler? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var sw = 0
    private var sh = 0
    private var rows = 16
    private var cols = 30
    private var mines = 99

    private var region: IntArray? = null
    private var grid: Grid? = null
    private var tpl: FloatArray? = null
    private var frame: Bitmap? = null
    private val marks = HashMap<Int, IntArray>()
    private var lastSig: String? = null
    private var running = false
    private var showMap = false
    @Volatile private var pauseUntil = 0L
    @Volatile private var tapping = false
    private var autoMode = false
    private var lastTapKey = ""
    private var tapRepeat = 0
    private lateinit var autoBtn: Button
    private var msg = "Нажмите «Поле» и коснитесь любой закрытой клетки"
    private var map = ""

    private lateinit var marksView: MarksView
    private lateinit var bar: LinearLayout
    private lateinit var status: TextView
    private var selecting: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY
        rows = intent.getIntExtra("rows", 16)
        cols = intent.getIntExtra("cols", 30)
        mines = intent.getIntExtra("mines", 99)
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundNotif()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        try {
            setupProjection(code, data)
            setupOverlay()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        worker = HandlerThread("saper-worker").also { it.start() }
        wh = Handler(worker!!.looper)
        wh?.postDelayed(tick, 600)
        return START_NOT_STICKY
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("saper", "Помощник сапёра", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "saper")
            .setContentTitle("Помощник сапёра работает")
            .setContentText("Откройте игру")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun setupProjection(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val mp = mpm.getMediaProjection(code, data)
        projection = mp
        val bounds = wm.currentWindowMetrics.bounds
        sw = bounds.width()
        sh = bounds.height()
        val dpi = resources.displayMetrics.densityDpi
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopSelf() }
            }
        }, main)
        val rd = ImageReader.newInstance(sw, sh, PixelFormat.RGBA_8888, 2)
        reader = rd
        vdisplay = mp.createVirtualDisplay(
            "saper", sw, sh, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            rd.surface, null, null
        )
    }

    private fun setupOverlay() {
        marksView = MarksView(this)
        val lp = WindowManager.LayoutParams(
            sw, sh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.alpha = 0.75f // выше 0.8 Android блокирует клики сквозь окно
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        wm.addView(marksView, lp)

        bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setBackgroundColor(0xCC202020.toInt())
        bar.setPadding(8, 4, 8, 4)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(makeButton("Поле") { startTap() })
        row.addView(makeButton("Вручн.") { startSelect() })
        autoBtn = makeButton("Авто: выкл") { toggleAuto() }
        row.addView(autoBtn)
        row.addView(makeButton("Карта") {
            showMap = !showMap
            lastSig = null
            render()
        })
        row.addView(makeButton("Снимок") { wh?.post { snapshot() } })
        row.addView(makeButton("✕") { stopSelf() })
        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 11f
        status.typeface = Typeface.MONOSPACE
        status.text = msg
        bar.addView(row)
        bar.addView(status)
        val bl = WindowManager.LayoutParams(
            (sw * 0.96).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        bl.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        wm.addView(bar, bl)
    }

    private fun makeButton(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 12f
        b.isAllCaps = false
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(14, 0, 14, 0)
        b.setOnClickListener { f() }
        return b
    }

    private fun setStatus(m: String) {
        msg = m
        render()
    }

    private fun render() {
        main.post { status.text = if (showMap && map.isNotEmpty()) msg + "\n" + map else msg }
    }

    private fun pushMarks() {
        val rg = region
        val g = grid
        val copy = HashMap<Int, IntArray>(marks)
        val c = cols
        main.post { marksView.update(rg, g, copy, c) }
    }

    private fun autoMines(r: Int, c: Int): Int {
        val a = minOf(r, c)
        val b = maxOf(r, c)
        return when {
            a == 8 && b == 8 -> 10
            a == 9 && b == 9 -> 10
            a == 16 && b == 16 -> 40
            a == 16 && b == 30 -> 99
            else -> (r * c * 0.16).toInt()
        }
    }

    private fun startTap() {
        if (selecting != null) return
        val v = TapView(this) { x, y ->
            main.post {
                selecting?.let { wm.removeView(it) }
                selecting = null
            }
            wh?.post { autoFind(x, y) }
        }
        val lp = WindowManager.LayoutParams(
            sw, sh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        selecting = v
        wm.addView(v, lp)
        setStatus("Коснитесь любой закрытой клетки игрового поля")
    }

    private fun autoFind(x: Int, y: Int) {
        pauseUntil = System.currentTimeMillis() + 4000
        marks.clear()
        pushMarks()
        setStatus("Ищу поле…")
        try {
            Thread.sleep(600) // дать затемнению и меткам исчезнуть с экрана
        } catch (e: InterruptedException) {
            return
        }
        refreshFrame()
        val f = frame
        if (f == null) {
            setStatus("Нет кадра экрана. Выберите «Весь экран» в окне записи и повторите")
            return
        }
        val px = IntArray(sw * sh)
        f.getPixels(px, 0, sw, 0, 0, sw, sh)
        val res = Vision.autoDetect(px, sw, sh, x, y)
        if (res == null) {
            setStatus("Не нашёл поле. Коснитесь закрытой клетки (лучше на новой игре) или нажмите «Вручн.»")
            return
        }
        region = res.region
        rows = res.rows
        cols = res.cols
        grid = res.grid
        tpl = res.tpl
        mines = autoMines(rows, cols)
        lastSig = null
        setStatus("Нашёл поле " + cols + "×" + rows + " (мин " + mines + "). Зелёная рамка — проверьте.")
        pauseUntil = System.currentTimeMillis() + 2800
        main.post { marksView.setOutline(true) }
        pushMarks()
        main.postDelayed({ marksView.setOutline(false) }, 2500)
    }

    // ------------------------------------------------ выбор поля вручную
    private fun startSelect() {
        if (selecting != null) return
        val v = SelectView(this) { rect ->
            main.post {
                selecting?.let { wm.removeView(it) }
                selecting = null
            }
            if (rect != null) {
                rect[0] = rect[0].coerceIn(0, sw - 1)
                rect[1] = rect[1].coerceIn(0, sh - 1)
                rect[2] = rect[2].coerceIn(1, sw)
                rect[3] = rect[3].coerceIn(1, sh)
                wh?.post {
                    region = rect
                    grid = null
                    tpl = null
                    marks.clear()
                    lastSig = null
                    pushMarks()
                    setStatus("Поле выбрано, калибрую…")
                    wh?.postDelayed({ calibrate() }, 700)
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            sw, sh,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        selecting = v
        wm.addView(v, lp)
        setStatus("Обведите игровое поле пальцем (чуть шире поля — можно)")
    }

    // ------------------------------------------------ захват экрана
    private fun refreshFrame() {
        val img = reader?.acquireLatestImage() ?: return
        try {
            val pl = img.planes[0]
            val rowPad = pl.rowStride - pl.pixelStride * sw
            val wide = Bitmap.createBitmap(sw + rowPad / pl.pixelStride, sh, Bitmap.Config.ARGB_8888)
            wide.copyPixelsFromBuffer(pl.buffer)
            val cut = Bitmap.createBitmap(wide, 0, 0, sw, sh)
            if (cut !== wide) wide.recycle()
            frame?.recycle()
            frame = cut
        } catch (e: Exception) {
            // кадр не удалось прочитать: оставляем предыдущий
        } finally {
            img.close()
        }
    }

    private fun regionPixels(rg: IntArray): IntArray? {
        refreshFrame()
        val f = frame ?: return null
        val w = rg[2] - rg[0]
        val h = rg[3] - rg[1]
        if (w < 50 || h < 50 || rg[2] > f.width || rg[3] > f.height) return null
        val px = IntArray(w * h)
        f.getPixels(px, 0, w, rg[0], rg[1], w, h)
        return px
    }

    private fun calibrate() {
        val rg = region
        if (rg == null) {
            setStatus("Сначала нажмите «Поле»")
            return
        }
        marks.clear()
        pushMarks()
        try {
            Thread.sleep(500) // дать метками исчезнуть с экрана
        } catch (e: InterruptedException) {
            return
        }
        val px = regionPixels(rg)
        if (px == null) {
            setStatus("Нет кадра экрана. Выберите «Весь экран» в окне записи и повторите")
            return
        }
        val w = rg[2] - rg[0]
        val h = rg[3] - rg[1]
        val g = try {
            Vision.detectGrid(px, w, h, rows, cols)
        } catch (e: Exception) {
            Vision.uniformGrid(w, h, rows, cols)
        }
        grid = g
        tpl = Vision.makeTemplate(px, w, h, g)
        lastSig = null
        setStatus("Готово (клетка ~" + Math.round(g.xs[1] - g.xs[0]) + " px). Откройте любую клетку. Флажки не ставьте.")
    }

    private fun snapshot() {
        refreshFrame()
        val f = frame
        if (f == null) {
            setStatus("Нет кадра экрана")
            return
        }
        val cv = ContentValues()
        cv.put(MediaStore.Images.Media.DISPLAY_NAME, "saper_" + System.currentTimeMillis() + ".png")
        cv.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Saper")
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
        if (uri == null) {
            setStatus("Не удалось сохранить снимок")
            return
        }
        contentResolver.openOutputStream(uri)?.use { f.compress(Bitmap.CompressFormat.PNG, 100, it) }
        setStatus("Снимок сохранён: Pictures/Saper")
    }

    // ------------------------------------------------ основной цикл
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                doTick()
            } catch (e: Exception) {
                setStatus("Ошибка: " + e.message)
            }
            wh?.postDelayed(this, 250)
        }
    }

    private fun doTick() {
        if (tapping || System.currentTimeMillis() < pauseUntil) return
        val bd = wm.currentWindowMetrics.bounds
        if (bd.width() != sw || bd.height() != sh) {
            autoMode = false
            updateAutoBtn()
            setStatus("Экран повернулся. Верните прежнюю ориентацию или перезапустите помощника")
            return
        }
        val rg = region ?: return
        val g = grid ?: return
        val t = tpl ?: return
        val w = rg[2] - rg[0]
        val h = rg[3] - rg[1]
        val px = regionPixels(rg) ?: return
        val b = Vision.readBoard(px, w, h, g, t)

        // метки на уже открытых клетках портят чтение цифр: убираем и ждём чистый кадр
        val dirty = marks.keys.filter { b[it / cols][it % cols] != Solver.UNK }
        if (dirty.isNotEmpty()) {
            for (k in dirty) marks.remove(k)
            pushMarks()
            return
        }
        val sb = StringBuilder()
        for (row in b) {
            for (v in row) sb.append(v).append(',')
            sb.append('|')
        }
        val sig = sb.toString()
        if (sig == lastSig) return
        lastSig = sig

        val res = Solver.solve(b, mines)
        marks.clear()
        if (res.err) {
            msg = "Числа не сходятся. Если игра проиграна — нажмите смайлик. Иначе нажмите «Поле» заново"
        } else {
            for (k in res.safe) marks[k] = intArrayOf(0, 0)
            for (k in res.mines) marks[k] = intArrayOf(1, 0)
            if (res.guess >= 0) {
                val pct = Math.round(res.guessP * 100).toInt()
                marks[res.guess] = intArrayOf(2, pct)
                msg = "Точных ходов нет. Жёлтая — лучший вариант, шанс мины $pct%"
            } else if (res.safe.isNotEmpty()) {
                msg = "Безопасно: " + res.safe.size + " (зелёные). Красные — мины."
            } else {
                msg = "Откройте любую клетку в игре."
            }
        }
        if (showMap) {
            val ms = StringBuilder()
            for (r in b.indices) {
                for (c in b[r].indices) {
                    val v = b[r][c]
                    val m = marks[r * cols + c]
                    ms.append(
                        if (v == Solver.UNK) {
                            if (m == null) '.' else if (m[0] == 0) '+' else if (m[0] == 1) '*' else '?'
                        } else if (v == 0) '_' else ('0' + v)
                    )
                }
                ms.append('\n')
            }
            map = ms.toString().trimEnd()
        } else {
            map = ""
        }
        pushMarks()
        render()
        if (autoMode && !res.err && res.safe.isNotEmpty()) autoTap(res.safe)
    }

    private fun updateAutoBtn() {
        main.post { autoBtn.text = if (autoMode) "Авто: вкл" else "Авто: выкл" }
    }

    private fun toggleAuto() {
        if (!autoMode) {
            if (TapService.instance == null) {
                setStatus("Включите службу: Настройки → Специальные возможности → «Помощник сапёра: нажатия»")
                try {
                    val i = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) {
                }
                return
            }
            autoMode = true
            tapRepeat = 0
            lastTapKey = ""
            lastSig = null
            setStatus("Авто включено: нажимаю безопасные клетки. Рискованные ходы — сами.")
        } else {
            autoMode = false
            setStatus("Авто выключено")
        }
        updateAutoBtn()
    }

    /** Нажимает все безопасные клетки (только достоверные, не угадывает). */
    private fun autoTap(cells: Set<Int>) {
        val svc = TapService.instance
        if (svc == null) {
            autoMode = false
            updateAutoBtn()
            setStatus("Служба нажатий выключена. Включите её в специальных возможностях.")
            return
        }
        val rg = region ?: return
        val g = grid ?: return
        val key = cells.sorted().joinToString(",")
        if (key == lastTapKey) tapRepeat++ else {
            tapRepeat = 0
            lastTapKey = key
        }
        if (tapRepeat >= 3) {
            autoMode = false
            updateAutoBtn()
            setStatus("Нажатия не срабатывают. Проверьте службу и что панель не закрывает поле.")
            return
        }
        val pts = ArrayList<IntArray>()
        for (k in cells) {
            val r = k / cols
            val c = k % cols
            val x = rg[0] + ((g.xs[c] + g.xs[c + 1]) / 2).toInt()
            val y = rg[1] + ((g.ys[r] + g.ys[r + 1]) / 2).toInt()
            pts.add(intArrayOf(x, y))
        }
        tapping = true
        main.post {
            svc.tapAll(pts) {
                pauseUntil = System.currentTimeMillis() + 300
                lastSig = null
                tapping = false
            }
        }
    }

    override fun onDestroy() {
        running = false
        wh?.removeCallbacksAndMessages(null)
        try { selecting?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { wm.removeView(marksView) } catch (e: Exception) { }
        try { wm.removeView(bar) } catch (e: Exception) { }
        try { vdisplay?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { projection?.stop() } catch (e: Exception) { }
        worker?.quitSafely()
        super.onDestroy()
    }
}
