package com.example.saper

/** Решатель сапёра: те же правила, что в версии для ПК. Клетка кодируется как r * cols + c. */
object Solver {
    const val UNK = -1

    class Result(
        val safe: Set<Int>,
        val mines: Set<Int>,
        val guess: Int,
        val guessP: Double,
        val err: Boolean
    )

    private class Con(val u: Set<Int>, val k: Int) {
        override fun equals(other: Any?): Boolean = other is Con && other.k == k && other.u == u
        override fun hashCode(): Int = u.hashCode() * 31 + k
    }

    fun solve(b: Array<IntArray>, total: Int): Result {
        val rows = b.size
        val cols = b[0].size
        val mines = HashSet<Int>()
        val safe = HashSet<Int>()
        var cons: List<Con> = emptyList()
        while (true) {
            val list = LinkedHashSet<Con>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val v = b[r][c]
                    if (v <= 0) continue
                    val unk = HashSet<Int>()
                    var m = 0
                    for (dr in -1..1) {
                        for (dc in -1..1) {
                            if (dr == 0 && dc == 0) continue
                            val nr = r + dr
                            val nc = c + dc
                            if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue
                            val key = nr * cols + nc
                            if (mines.contains(key)) {
                                m++
                            } else if (b[nr][nc] == UNK && !safe.contains(key)) {
                                unk.add(key)
                            }
                        }
                    }
                    val k = v - m
                    if (k < 0 || k > unk.size) {
                        return Result(emptySet(), emptySet(), -1, 0.0, true)
                    }
                    if (unk.isNotEmpty()) list.add(Con(unk, k))
                }
            }
            cons = list.toList()
            val ns = HashSet<Int>()
            val nm = HashSet<Int>()
            for (q in cons) {
                if (q.k == 0) ns.addAll(q.u) else if (q.k == q.u.size) nm.addAll(q.u)
            }
            if (ns.isEmpty() && nm.isEmpty()) {
                for (a in cons) {
                    for (d in cons) {
                        if (a.u.size < d.u.size && d.u.containsAll(a.u)) {
                            val diff = HashSet<Int>(d.u)
                            diff.removeAll(a.u)
                            val kd = d.k - a.k
                            if (kd == 0) ns.addAll(diff) else if (kd == diff.size) nm.addAll(diff)
                        }
                    }
                }
            }
            if (ns.isEmpty() && nm.isEmpty()) break
            safe.addAll(ns)
            mines.addAll(nm)
        }

        var guess = -1
        var gp = 0.0
        if (safe.isEmpty()) {
            val unknown = ArrayList<Int>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val key = r * cols + c
                    if (b[r][c] == UNK && !mines.contains(key)) unknown.add(key)
                }
            }
            if (unknown.isNotEmpty()) {
                val dens = maxOf(total - mines.size, 0).toDouble() / unknown.size
                val pr = HashMap<Int, Double>()
                for (q in cons) {
                    val p = q.k.toDouble() / q.u.size
                    for (cell in q.u) {
                        val old = pr[cell]
                        if (old == null || p > old) pr[cell] = p
                    }
                }
                var best = -1
                var bp = 2.0
                for (cell in unknown) {
                    val p = pr[cell] ?: dens
                    if (p < bp) {
                        bp = p
                        best = cell
                    }
                }
                guess = best
                gp = bp
            }
        }
        return Result(safe, mines, guess, gp, false)
    }
}
