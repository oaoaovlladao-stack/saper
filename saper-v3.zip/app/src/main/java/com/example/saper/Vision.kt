package com.example.saper

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Границы клеток внутри выделенной области (в пикселях области). */
class Grid(val xs: DoubleArray, val ys: DoubleArray)

/** Результат автопоиска: область поля на экране, размеры, сетка и образ закрытой клетки. */
class AutoResult(
    val region: IntArray,
    val rows: Int,
    val cols: Int,
    val grid: Grid,
    val tpl: FloatArray,
    val pitch: Double
)

/** Чтение поля из пикселей: поиск сетки, закрытые/открытые клетки, цифры. */
object Vision {
    private const val N = 8

    // Центр клетки (там рисуются метки) при определении «закрыта/открыта» не смотрим.
    private val FRAME: IntArray = (0 until N * N).filter { i ->
        !((i / N) in 2..5 && (i % N) in 2..5)
    }.toIntArray()

    // Цвета цифр 1..8: классический сапёр и стиль Google.
    private val PALETTE: Array<Array<IntArray>> = arrayOf(
        arrayOf(intArrayOf(0, 0, 255), intArrayOf(25, 118, 210)),
        arrayOf(intArrayOf(0, 128, 0), intArrayOf(56, 142, 60)),
        arrayOf(intArrayOf(255, 0, 0), intArrayOf(211, 47, 47)),
        arrayOf(intArrayOf(0, 0, 128), intArrayOf(123, 31, 162)),
        arrayOf(intArrayOf(128, 0, 0), intArrayOf(255, 143, 0)),
        arrayOf(intArrayOf(0, 128, 128), intArrayOf(0, 151, 167)),
        arrayOf(intArrayOf(0, 0, 0), intArrayOf(66, 66, 66)),
        arrayOf(intArrayOf(128, 128, 128), intArrayOf(158, 158, 158))
    )

    // ---------------------------------------------------------- сетка
    fun uniformGrid(w: Int, h: Int, rows: Int, cols: Int): Grid {
        return Grid(
            DoubleArray(cols + 1) { it * w.toDouble() / cols },
            DoubleArray(rows + 1) { it * h.toDouble() / rows }
        )
    }

    private fun smooth(g: DoubleArray, k: Int): DoubleArray {
        val n = g.size
        val pre = DoubleArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + g[i]
        return DoubleArray(n) { i ->
            val a = max(0, i - k)
            val b = min(n, i + k + 1)
            (pre[b] - pre[a]) / (b - a)
        }
    }

    /** Ищет начало и шаг n клеток по профилю перепадов яркости raw. Возвращает [начало, шаг]. */
    private fun fitAxis(raw: DoubleArray, n: Int, len: Int): DoubleArray {
        val g = smooth(raw, 3)
        val p0 = len.toDouble() / n
        var best = -1.0
        var bo = 0.0
        var bp = p0
        var p = p0 * 0.55
        while (p <= p0 * 1.15) {
            var o = -0.6 * p
            val hi = len - n * p + 0.6 * p
            while (o <= hi) {
                var sc = 0.0
                for (k in 0..n) {
                    val x = Math.round(o + k * p).toInt()
                    if (x >= 0 && x < g.size) sc += g[x]
                }
                if (sc > best) {
                    best = sc
                    bo = o
                    bp = p
                }
                o += 0.5
            }
            p += 0.1
        }
        // уточнение начала: у толстой рамки клетки сглаженный пик смещён, сырой точнее
        var ro = bo
        var rs = -1.0
        var o2 = bo - 6
        while (o2 <= bo + 6) {
            var sc = 0.0
            for (k in 0..n) {
                val x = Math.round(o2 + k * bp).toInt()
                if (x >= 0 && x < raw.size) sc += raw[x]
            }
            if (sc > rs) {
                rs = sc
                ro = o2
            }
            o2 += 0.5
        }
        return doubleArrayOf(ro + 1.0, bp)
    }

    fun detectGrid(px: IntArray, w: Int, h: Int, rows: Int, cols: Int): Grid {
        val g = IntArray(w * h)
        for (i in 0 until w * h) {
            val p = px[i]
            g[i] = (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100
        }
        val gx = DoubleArray(max(w - 1, 1))
        val gy = DoubleArray(max(h - 1, 1))
        for (y in 0 until h) {
            val o = y * w
            for (x in 0 until w - 1) {
                gx[x] += abs(g[o + x + 1] - g[o + x]).toDouble()
            }
            if (y < h - 1) {
                val o2 = o + w
                for (x in 0 until w) {
                    gy[y] += abs(g[o2 + x] - g[o + x]).toDouble()
                }
            }
        }
        val fx = fitAxis(gx, cols, w)
        val fy = fitAxis(gy, rows, h)
        return Grid(
            DoubleArray(cols + 1) { fx[0] + it * fx[1] },
            DoubleArray(rows + 1) { fy[0] + it * fy[1] }
        )
    }

    // ---------------------------------------------------------- клетки
    private fun box(g: Grid, r: Int, c: Int, w: Int, h: Int): IntArray {
        val x0 = max(0, g.xs[c].roundToInt())
        val y0 = max(0, g.ys[r].roundToInt())
        val x1 = min(w, g.xs[c + 1].roundToInt())
        val y1 = min(h, g.ys[r + 1].roundToInt())
        return if (x1 - x0 < 8 || y1 - y0 < 8) {
            intArrayOf(0, 0, min(w, 16), min(h, 16))
        } else {
            intArrayOf(x0, y0, x1, y1)
        }
    }

    private fun thumb(px: IntArray, w: Int, bx: IntArray): FloatArray {
        val out = FloatArray(N * N * 3)
        val cw = bx[2] - bx[0]
        val ch = bx[3] - bx[1]
        for (i in 0 until N) {
            val ya = bx[1] + ch * i / N
            val yb = max(ya + 1, bx[1] + ch * (i + 1) / N)
            for (j in 0 until N) {
                val xa = bx[0] + cw * j / N
                val xb = max(xa + 1, bx[0] + cw * (j + 1) / N)
                var sr = 0L
                var sg = 0L
                var sb = 0L
                var cnt = 0
                for (y in ya until yb) {
                    for (x in xa until xb) {
                        val p = px[y * w + x]
                        sr += (p shr 16) and 255
                        sg += (p shr 8) and 255
                        sb += p and 255
                        cnt++
                    }
                }
                val o = (i * N + j) * 3
                out[o] = sr.toFloat() / cnt
                out[o + 1] = sg.toFloat() / cnt
                out[o + 2] = sb.toFloat() / cnt
            }
        }
        return out
    }

    /** На чистом поле все клетки закрыты: усредняем их вид. */
    fun makeTemplate(px: IntArray, w: Int, h: Int, g: Grid): FloatArray {
        val rows = g.ys.size - 1
        val cols = g.xs.size - 1
        val acc = FloatArray(N * N * 3)
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val t = thumb(px, w, box(g, r, c, w, h))
                for (i in acc.indices) acc[i] += t[i]
            }
        }
        val n = (rows * cols).toFloat()
        for (i in acc.indices) acc[i] /= n
        return acc
    }

    private fun diff(t: FloatArray, tpl: FloatArray): Float {
        var s = 0f
        for (f in FRAME) {
            for (ch in 0..2) s += abs(t[f * 3 + ch] - tpl[f * 3 + ch])
        }
        return s / (FRAME.size * 3)
    }

    private fun sq(a: Int, b: Int): Int = (a - b) * (a - b)

    /** Цифры-кандидаты от самой вероятной к менее вероятной; 0 (пусто) всегда в конце. */
    private fun candidates(px: IntArray, w: Int, bx: IntArray): IntArray {
        val cw = bx[2] - bx[0]
        val ch = bx[3] - bx[1]
        val xa = bx[0] + (cw * 0.28).roundToInt()
        val xb = bx[0] + (cw * 0.72).roundToInt()
        val ya = bx[1] + (ch * 0.2).roundToInt()
        val yb = bx[1] + (ch * 0.8).roundToInt()
        val area = (xb - xa) * (yb - ya)

        val hist = IntArray(4096)
        for (y in bx[1] until bx[3]) {
            for (x in bx[0] until bx[2]) {
                val p = px[y * w + x]
                val key = (((p shr 20) and 15) shl 8) or (((p shr 12) and 15) shl 4) or ((p shr 4) and 15)
                hist[key]++
            }
        }
        var bk = 0
        for (i in 1 until 4096) if (hist[i] > hist[bk]) bk = i
        val br = ((bk shr 8) and 15) * 16 + 8
        val bg = ((bk shr 4) and 15) * 16 + 8
        val bb = (bk and 15) * 16 + 8

        val pure = IntArray(9)
        val soft = IntArray(9)
        for (y in ya until yb) {
            for (x in xa until xb) {
                val p = px[y * w + x]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                if (sq(r, br) + sq(g, bg) + sq(b, bb) < 3600) continue
                var d1 = Int.MAX_VALUE
                var n1 = 0
                var d2 = Int.MAX_VALUE
                var n2 = 0
                for (n in 1..8) {
                    for (col in PALETTE[n - 1]) {
                        val d = sq(r, col[0]) + sq(g, col[1]) + sq(b, col[2])
                        if (d < d1) {
                            d1 = d
                            n1 = n
                        }
                        if (n <= 6 && d < d2) {
                            d2 = d
                            n2 = n
                        }
                    }
                }
                if (d1 < 1225) pure[n1]++
                if (d2 < 5625) soft[n2]++
            }
        }

        val score = DoubleArray(9)
        for (n in 1..8) {
            val sc: Double = if (n >= 7) {
                // серый и чёрный легко путаются с рамками и тенями: нужно много пикселей
                if (pure[n] >= max(8.0, area * 0.06)) pure[n].toDouble() else 0.0
            } else {
                pure[n] + 0.3 * soft[n]
            }
            if (sc >= max(3.0, area * 0.015)) score[n] = sc
        }
        val ranked = (1..8).filter { score[it] > 0.0 }.sortedByDescending { score[it] }
        val out = IntArray(ranked.size + 1)
        for (i in ranked.indices) out[i] = ranked[i]
        out[ranked.size] = 0
        return out
    }

    fun readBoard(px: IntArray, w: Int, h: Int, g: Grid, tpl: FloatArray): Array<IntArray> {
        val rows = g.ys.size - 1
        val cols = g.xs.size - 1
        val board = Array(rows) { IntArray(cols) { Solver.UNK } }
        val cand = HashMap<Int, IntArray>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val bx = box(g, r, c, w, h)
                if (diff(thumb(px, w, bx), tpl) >= 22f) {
                    val lst = candidates(px, w, bx)
                    cand[r * cols + c] = lst
                    board[r][c] = lst[0]
                }
            }
        }
        // проверка здравого смысла: цифра не может быть больше числа закрытых соседей
        for (pass in 0 until 3) {
            var fixed = false
            for ((key, lst) in cand) {
                val r = key / cols
                val c = key % cols
                val v = board[r][c]
                var cn = 0
                for (dr in -1..1) {
                    for (dc in -1..1) {
                        if (dr == 0 && dc == 0) continue
                        val nr = r + dr
                        val nc = c + dc
                        if (nr in 0 until rows && nc in 0 until cols && board[nr][nc] == Solver.UNK) cn++
                    }
                }
                if (v > cn) {
                    board[r][c] = lst.firstOrNull { it <= cn } ?: 0
                    fixed = true
                }
            }
            if (!fixed) break
        }
        return board
    }

    // ---------------------------------------------------------- автопоиск поля
    private fun gray(p: Int): Int =
        (((p shr 16) and 255) * 30 + ((p shr 8) and 255) * 59 + (p and 255) * 11) / 100

    /** Шаг клеток по автокорреляции профиля перепадов яркости; -1 если не нашли. */
    private fun estimatePitch(prof: DoubleArray): Int {
        val n = prof.size
        var m = 0.0
        for (v in prof) m += v
        m /= n
        val pr = DoubleArray(n) { prof[it] - m }
        val hi = min(300, n / 3)
        if (hi < 20) return -1
        val rr = DoubleArray(hi + 2)
        for (t in 12..hi + 1) {
            var s = 0.0
            for (i in 0 until n - t) s += pr[i] * pr[i + t]
            rr[t] = s / (n - t)
        }
        var rmax = -1e300
        for (t in 14 until hi) if (rr[t] > rmax) rmax = rr[t]
        for (t in 14 until hi) {
            if (rr[t] >= 0.9 * rmax && rr[t] >= rr[t - 1] && rr[t] >= rr[t + 1]) return t
        }
        return -1
    }

    /** Точные начало и шаг сетки возле точки касания. Возвращает [начало, шаг]. */
    private fun fitLocal(raw: DoubleArray, p0: Int, center: Int): DoubleArray {
        val g = smooth(raw, 3)
        val lo = max(0.0, center - 8.0 * p0)
        val hi = min((g.size - 1).toDouble(), center + 8.0 * p0)
        var best = -1.0
        var bph = 0.0
        var bp = p0.toDouble()
        var p = p0 * 0.97
        while (p <= p0 * 1.03) {
            var ph = 0.0
            while (ph < p) {
                var sc = 0.0
                var x = ph + floor((lo - ph) / p) * p
                while (x <= hi) {
                    val xi = Math.round(x).toInt()
                    if (xi >= lo && xi <= hi) sc += g[xi]
                    x += p
                }
                if (sc > best) {
                    best = sc
                    bph = ph
                    bp = p
                }
                ph += 0.5
            }
            p += 0.05
        }
        var bo = bph
        var bs = -1.0
        var o = bph - 6
        while (o <= bph + 6) {
            var sc = 0.0
            var x = o + floor((lo - o) / bp) * bp
            while (x <= hi) {
                val xi = Math.round(x).toInt()
                if (xi >= 0 && xi < raw.size && xi >= lo) sc += raw[xi]
                x += bp
            }
            if (sc > bs) {
                bs = sc
                bo = o
            }
            o += 0.5
        }
        return doubleArrayOf(bo + 1.0, bp)
    }

    /**
     * Находит поле по одному касанию закрытой клетки: шаг сетки, границы, число строк и столбцов.
     * px — весь кадр экрана (w x h), (tx, ty) — точка касания.
     */
    fun autoDetect(px: IntArray, w: Int, h: Int, tx: Int, ty: Int): AutoResult? {
        val ya = max(0, ty - 12)
        val yb = min(h, ty + 12)
        val xa = max(0, tx - 12)
        val xb = min(w, tx + 12)
        val gx = DoubleArray(w - 1)
        for (y in ya until yb) {
            val o = y * w
            for (x in 0 until w - 1) gx[x] += abs(gray(px[o + x + 1]) - gray(px[o + x])).toDouble()
        }
        val gy = DoubleArray(h - 1)
        for (y in 0 until h - 1) {
            for (x in xa until xb) gy[y] += abs(gray(px[(y + 1) * w + x]) - gray(px[y * w + x])).toDouble()
        }
        val px0 = estimatePitch(gx)
        val py0 = estimatePitch(gy)
        if (px0 <= 0 || py0 <= 0) return null
        val fx = fitLocal(gx, px0, tx)
        val fy = fitLocal(gy, py0, ty)
        val ox = fx[0]
        val sx = fx[1]
        val oy = fy[0]
        val sy = fy[1]
        val kx0 = floor((tx - ox) / sx).toInt()
        val ky0 = floor((ty - oy) / sy).toInt()

        fun cbox(kx: Int, ky: Int): IntArray? {
            val x0 = Math.round(ox + kx * sx).toInt()
            val y0 = Math.round(oy + ky * sy).toInt()
            val x1 = Math.round(ox + (kx + 1) * sx).toInt()
            val y1 = Math.round(oy + (ky + 1) * sy).toInt()
            if (x0 < 0 || y0 < 0 || x1 > w || y1 > h || x1 - x0 < 8 || y1 - y0 < 8) return null
            return intArrayOf(x0, y0, x1, y1)
        }

        val b0 = cbox(kx0, ky0) ?: return null
        val tpl0 = thumb(px, w, b0)
        fun same(kx: Int, ky: Int): Boolean {
            val bx = cbox(kx, ky) ?: return false
            return diff(thumb(px, w, bx), tpl0) < 24f
        }

        var l = kx0
        while (same(l - 1, ky0)) l--
        var r = kx0
        while (same(r + 1, ky0)) r++
        var t = ky0
        while (same(kx0, t - 1)) t--
        var b = ky0
        while (same(kx0, b + 1)) b++
        // строки и столбцы с открытыми клетками обрывают проход рано: берём самый дальний край
        for (pass in 0 until 2) {
            for (c in l..r) {
                if (same(c, ky0)) {
                    var k = ky0
                    while (same(c, k - 1)) k--
                    if (k < t) t = k
                    k = ky0
                    while (same(c, k + 1)) k++
                    if (k > b) b = k
                }
            }
            for (rr in t..b) {
                if (same(kx0, rr)) {
                    var k = kx0
                    while (same(k - 1, rr)) k--
                    if (k < l) l = k
                    k = kx0
                    while (same(k + 1, rr)) k++
                    if (k > r) r = k
                }
            }
        }
        val cols = r - l + 1
        val rows = b - t + 1
        if (cols < 5 || rows < 5 || cols > 80 || rows > 80) return null

        val rx0 = max(0, Math.round(ox + l * sx).toInt())
        val ry0 = max(0, Math.round(oy + t * sy).toInt())
        val rx1 = min(w, Math.round(ox + (r + 1) * sx).toInt())
        val ry1 = min(h, Math.round(oy + (b + 1) * sy).toInt())
        val rw = rx1 - rx0
        val rh = ry1 - ry0
        if (rw < 50 || rh < 50) return null
        val sub = IntArray(rw * rh)
        for (y in 0 until rh) System.arraycopy(px, (ry0 + y) * w + rx0, sub, y * rw, rw)

        val grid = detectGrid(sub, rw, rh, rows, cols)
        // образ закрытой клетки: среднее по клеткам, похожим на нажатую
        val acc = FloatArray(N * N * 3)
        var cnt = 0
        for (rr in 0 until rows) {
            for (cc in 0 until cols) {
                val th = thumb(sub, rw, box(grid, rr, cc, rw, rh))
                if (diff(th, tpl0) < 24f) {
                    for (i in acc.indices) acc[i] += th[i]
                    cnt++
                }
            }
        }
        val tpl = if (cnt > 0) FloatArray(acc.size) { acc[it] / cnt } else tpl0
        return AutoResult(intArrayOf(rx0, ry0, rx1, ry1), rows, cols, grid, tpl, sx)
    }
}
