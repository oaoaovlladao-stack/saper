package com.example.saper

/** Решатель сапёра: те же правила, что в версии для ПК. Клетка кодируется как r * cols + c. */
object Solver {
    const val UNK = -1

    class Result(
        val safe: Set<Int>,
        val mines: Set<Int>,
        val guess: Int,
        val guessP: Double,
        val err: Boolean
    )

    private class Con(val u: Set<Int>, val k: Int) {
        override fun equals(other: Any?): Boolean = other is Con && other.k == k && other.u == u
        override fun hashCode(): Int = u.hashCode() * 31 + k
    }

    fun solve(b: Array<IntArray>, total: Int): Result {
        val rows = b.size
        val cols = b[0].size
        val mines = HashSet<Int>()
        val safe = HashSet<Int>()
        var cons: List<Con> = emptyList()
        while (true) {
            val list = LinkedHashSet<Con>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val v = b[r][c]
                    if (v <= 0) continue
                    val unk = HashSet<Int>()
                    var m = 0
                    for (dr in -1..1) {
                        for (dc in -1..1) {
                            if (dr == 0 && dc == 0) continue
                            val nr = r + dr
                            val nc = c + dc
                            if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue
                            val key = nr * cols + nc
                            if (mines.contains(key)) {
                                m++
                            } else if (b[nr][nc] == UNK && !safe.contains(key)) {
                                unk.add(key)
                            }
                        }
                    }
                    val k = v - m
                    if (k < 0 || k > unk.size) {
                        return Result(emptySet(), emptySet(), -1, 0.0, true)
                    }
                    if (unk.isNotEmpty()) list.add(Con(unk, k))
                }
            }
            cons = list.toList()
            val ns = HashSet<Int>()
            val nm = HashSet<Int>()
            for (q in cons) {
                if (q.k == 0) ns.addAll(q.u) else if (q.k == q.u.size) nm.addAll(q.u)
            }
            if (ns.isEmpty() && nm.isEmpty()) {
                for (a in cons) {
                    for (d in cons) {
                        if (a.u.size < d.u.size && d.u.containsAll(a.u)) {
                            val diff = HashSet<Int>(d.u)
                            diff.removeAll(a.u)
                            val kd = d.k - a.k
                            if (kd == 0) ns.addAll(diff) else if (kd == diff.size) nm.addAll(diff)
                        }
                    }
                }
            }
            if (ns.isEmpty() && nm.isEmpty()) break
            safe.addAll(ns)
            mines.addAll(nm)
        }

        var guess = -1
        var gp = 0.0
        if (safe.isEmpty()) {
            val ex = try {
                exact(b, total, mines, cons, rows, cols)
            } catch (e: Exception) {
                null
            }
            if (ex != null) return ex
            val unknown = ArrayList<Int>()
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val key = r * cols + c
                    if (b[r][c] == UNK && !mines.contains(key)) unknown.add(key)
                }
            }
            if (unknown.isNotEmpty()) {
                val dens = maxOf(total - mines.size, 0).toDouble() / unknown.size
                val pr = HashMap<Int, Double>()
                for (q in cons) {
                    val p = q.k.toDouble() / q.u.size
                    for (cell in q.u) {
                        val old = pr[cell]
                        if (old == null || p > old) pr[cell] = p
                    }
                }
                var best = -1
                var bp = 2.0
                for (cell in unknown) {
                    val p = pr[cell] ?: dens
                    if (p < bp) {
                        bp = p
                        best = cell
                    }
                }
                guess = best
                gp = bp
            }
        }
        return Result(safe, mines, guess, gp, false)
    }

    // ---------------------------------------------------------- точные вероятности
    private val LF: DoubleArray = DoubleArray(10001).also {
        for (i in 1..10000) it[i] = it[i - 1] + Math.log(i.toDouble())
    }

    private fun lcomb(n: Int, k: Int): Double =
        if (k < 0 || k > n) -1e300 else LF[n] - LF[k] - LF[n - k]

    private class CompEnum(
        val n: Int,
        val of: Array<IntArray>,
        val ks: IntArray,
        sizes: IntArray,
        val budget: Int
    ) {
        val cnt = IntArray(ks.size)
        val left = sizes.copyOf()
        val assign = BooleanArray(n)
        val counts = DoubleArray(n + 1)
        val cc = Array(n) { DoubleArray(n + 1) }
        var nodes = 0
        var overflow = false

        fun rec(i: Int, m: Int) {
            if (overflow) return
            nodes++
            if (nodes > budget) {
                overflow = true
                return
            }
            if (i == n) {
                counts[m] += 1.0
                for (x in 0 until n) if (assign[x]) cc[x][m] += 1.0
                return
            }
            val cs = of[i]
            for (v in 0..1) {
                for (j in cs) {
                    left[j]--
                    cnt[j] += v
                }
                var ok = true
                for (j in cs) {
                    if (cnt[j] > ks[j] || cnt[j] + left[j] < ks[j]) ok = false
                }
                if (ok) {
                    assign[i] = v == 1
                    rec(i + 1, m + v)
                }
                for (j in cs) {
                    left[j]++
                    cnt[j] -= v
                }
            }
        }
    }

    private class CompRes(val cells: IntArray, val counts: DoubleArray, val cc: Array<DoubleArray>)

    private fun conv(a: DoubleArray, b: DoubleArray): DoubleArray {
        val out = DoubleArray(a.size + b.size - 1)
        for (i in a.indices) {
            if (a[i] == 0.0) continue
            for (j in b.indices) out[i + j] += a[i] * b[j]
        }
        return out
    }

    private fun norm(a: DoubleArray): DoubleArray {
        var m = 0.0
        for (v in a) if (v > m) m = v
        if (m <= 0.0) return a
        return DoubleArray(a.size) { a[it] / m }
    }

    private fun totalDist(results: List<CompRes>, skip: Int): DoubleArray {
        var t = doubleArrayOf(1.0)
        for (i in results.indices) {
            if (i == skip) continue
            t = norm(conv(t, results[i].counts))
        }
        return t
    }

    /**
     * Точная вероятность мины для каждой закрытой клетки: перебор всех согласованных расстановок
     * мин на границе, с учётом общего числа мин. Возвращает null, если перебор слишком большой.
     */
    private fun exact(
        b: Array<IntArray>,
        total: Int,
        mines: HashSet<Int>,
        cons: List<Con>,
        rows: Int,
        cols: Int
    ): Result? {
        val unknown = ArrayList<Int>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val key = r * cols + c
                if (b[r][c] == UNK && !mines.contains(key)) unknown.add(key)
            }
        }
        if (unknown.isEmpty()) return Result(emptySet(), mines, -1, 0.0, false)
        val rem = total - mines.size

        val frontSet = java.util.TreeSet<Int>()
        for (q in cons) frontSet.addAll(q.u)
        val front = frontSet.toIntArray()
        val idx = HashMap<Int, Int>()
        for (i in front.indices) idx[front[i]] = i

        // компоненты связности (какие клетки связаны общими цифрами)
        val parent = IntArray(front.size) { it }
        fun find(a: Int): Int {
            var x = a
            while (parent[x] != x) {
                parent[x] = parent[parent[x]]
                x = parent[x]
            }
            return x
        }
        for (q in cons) {
            val l = q.u.map { idx[it]!! }
            for (i in 1 until l.size) parent[find(l[i])] = find(l[0])
        }
        val compCells = HashMap<Int, ArrayList<Int>>()
        for (x in front) compCells.getOrPut(find(idx[x]!!)) { ArrayList() }.add(x)
        val compCons = HashMap<Int, ArrayList<Con>>()
        for (q in cons) compCons.getOrPut(find(idx[q.u.first()]!!)) { ArrayList() }.add(q)

        val results = ArrayList<CompRes>()
        var nodesLeft = 400000
        for ((root, cellsList) in compCells) {
            val cells = cellsList.sorted().toIntArray()
            if (cells.size > 150) return null
            val ci = HashMap<Int, Int>()
            for (i in cells.indices) ci[cells[i]] = i
            val cl = compCons[root] ?: return null
            val ofLists = Array(cells.size) { ArrayList<Int>() }
            val ks = IntArray(cl.size)
            val sizes = IntArray(cl.size)
            for (j in cl.indices) {
                ks[j] = cl[j].k
                sizes[j] = cl[j].u.size
                for (cell in cl[j].u) ofLists[ci[cell]!!].add(j)
            }
            val of = Array(cells.size) { ofLists[it].toIntArray() }
            val en = CompEnum(cells.size, of, ks, sizes, nodesLeft)
            en.rec(0, 0)
            if (en.overflow) return null
            nodesLeft -= en.nodes
            results.add(CompRes(cells, en.counts, en.cc))
        }

        val f = unknown.size - front.size
        val full = totalDist(results, -1)
        val lw = DoubleArray(full.size) { s ->
            if (full[s] > 0.0 && rem - s >= 0 && rem - s <= f) Math.log(full[s]) + lcomb(f, rem - s) else -1e300
        }
        var mx = -1e300
        for (v in lw) if (v > mx) mx = v
        if (mx < -1e200) return Result(emptySet(), emptySet(), -1, 0.0, true)
        val w = DoubleArray(lw.size) { if (lw[it] > -1e200) Math.exp(lw[it] - mx) else 0.0 }
        var z = 0.0
        for (v in w) z += v

        val prob = HashMap<Int, Double>()
        for (i in results.indices) {
            val res = results[i]
            val other = totalDist(results, i)
            var denom = 0.0
            for (m in res.counts.indices) {
                if (res.counts[m] == 0.0) continue
                for (s2 in other.indices) {
                    val s = m + s2
                    if (other[s2] != 0.0 && rem - s >= 0 && rem - s <= f) {
                        denom += res.counts[m] * other[s2] * Math.exp(lcomb(f, rem - s) - mx)
                    }
                }
            }
            for (xi in res.cells.indices) {
                var num = 0.0
                for (m in res.cc[xi].indices) {
                    val cx = res.cc[xi][m]
                    if (cx == 0.0) continue
                    for (s2 in other.indices) {
                        val s = m + s2
                        if (other[s2] != 0.0 && rem - s >= 0 && rem - s <= f) {
                            num += cx * other[s2] * Math.exp(lcomb(f, rem - s) - mx)
                        }
                    }
                }
                prob[res.cells[xi]] = if (denom > 0.0) num / denom else 1.0
            }
        }
        if (f > 0) {
            var e = 0.0
            for (s in w.indices) if (rem - s >= 0 && rem - s <= f) e += w[s] * (rem - s)
            val pnf = e / z / f
            for (x in unknown) if (!idx.containsKey(x)) prob[x] = pnf
        }

        val eps = 1e-9
        val newSafe = HashSet<Int>()
        for ((x, p) in prob) {
            if (p < eps) newSafe.add(x) else if (p > 1 - eps) mines.add(x)
        }
        if (newSafe.isNotEmpty()) return Result(newSafe, mines, -1, 0.0, false)

        var best = -1
        var bp = 2.0
        for ((x, p0) in prob) {
            val p = minOf(1.0, maxOf(0.0, p0))
            val isFront = idx.containsKey(x)
            val bestFront = best >= 0 && idx.containsKey(best)
            if (p < bp - eps || (Math.abs(p - bp) <= eps && isFront && !bestFront)) {
                bp = p
                best = x
            }
        }
        return Result(emptySet(), mines, best, bp, false)
    }
}
