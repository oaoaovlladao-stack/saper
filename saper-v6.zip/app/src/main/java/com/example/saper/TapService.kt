package com.example.saper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Служба «специальных возможностей»: умеет только нажимать в заданных точках экрана. */
class TapService : AccessibilityService() {
    companion object {
        @Volatile
        var instance: TapService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Нажимает по очереди все точки (по 10 за раз, с небольшим интервалом). */
    fun tapAll(points: List<IntArray>, onDone: () -> Unit) {
        runBatch(points.chunked(10), 0, onDone)
    }

    private fun runBatch(batches: List<List<IntArray>>, i: Int, onDone: () -> Unit) {
        if (i >= batches.size) {
            onDone()
            return
        }
        val builder = GestureDescription.Builder()
        for ((j, p) in batches[i].withIndex()) {
            val path = Path()
            path.moveTo(p[0].toFloat(), p[1].toFloat())
            builder.addStroke(GestureDescription.StrokeDescription(path, j * 70L, 40L))
        }
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                runBatch(batches, i + 1, onDone)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                onDone()
            }
        }
        val ok = dispatchGesture(builder.build(), cb, null)
        if (!ok) onDone()
    }
}
